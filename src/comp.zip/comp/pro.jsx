

export default function Projects(second) {
    return(
        <>
        <section id="projects">
              <div className="m2">
                  <div className="head"> <h1><i class="fa-solid fa-code"></i>  Featured
Projects</h1></div>

            <div id="pm2">
                <div className="temp" id="tictac">
                    <div className="imgp" >
                       
                    </div>
                    <h2>Tic Tac Toe</h2>
                    <p>My first simple and woking project using html,css and Java script</p>
                    <ul className="tech"> 
                        <li>HTML</li>
                        <li>CSS</li>
                         <li>Java Script</li>
                    </ul>

                    <ul className="live">
                        <li><a href="https://tic-tac-toe-eight-delta-58.vercel.app/" target="_blank"><i className="fa-solid fa-rocket"></i> Live Demo</a></li>
                         <li><a href="https://github.com/JenishMacwan230/TicTacToe" target="_blank"><i class="fa-brands fa-github"></i> Code</a></li>
                    </ul>
                </div>
                 {/* <div className="temp" id="tictac">
                    <div className="imgp" >
                       
                    </div>
                    <h2>Tic Tac Toe</h2>
                    <p>My first simple and woking project using html,css and Java script</p>
                    <ul className="tech"> 
                        <li>HTML</li>
                        <li>CSS</li>
                         <li>Java Script</li>
                    </ul>

                    <ul className="live">
                        <li><a href="" target="_blank"><i className="fa-solid fa-rocket"></i> Live Demo</a></li>
                         <li><a href=""><i class="fa-brands fa-github"></i> Code</a></li>
                    </ul>
                </div> */}
                 {/* <div className="temp" id="tictac">
                    <div className="imgp" >
                       
                    </div>
                    <h2>Tic Tac Toe</h2>
                    <p>My first simple and wdjcnscn dknvdk kdvdk kdvdkvndkvk vndv kndvdknv kdnvdkv  dcnc kdvdk n dkvdkn dkcvndck knvd dkvdoking project using html,css and Java script</p>
                    <ul className="tech"> 
                        <li>HTML</li>
                        <li>CSS</li>
                         <li>Java Script</li>
                    </ul>

                    <ul className="live">
                        <li><a href="" target="_blank"><i className="fa-solid fa-rocket"></i> Live Demo</a></li>
                         <li><a href=""><i class="fa-brands fa-github"></i> Code</a></li>
                    </ul>
                </div> */}
                {/* <div className="temp" id="tictac">
                    <div className="imgp" >
                       
                    </div>
                    <h2>Tic Tac Toe</h2>
                    <p>My first simple and wdjcnscn dknvdk kdvdk kdvdkvndkvk vndv kndvdknv kdnvdkv  dcnc kdvdk n dkvdkn dkcvndck knvd dkvdoking project using html,css and Java script</p>
                    <ul className="tech"> 
                        <li>HTML</li>
                        <li>CSS</li>
                         <li>Java Script</li>
                    </ul>

                    <ul className="live">
                        <li><a href="" target="_blank"><i className="fa-solid fa-rocket"></i> Live Demo</a></li>
                         <li><a href=""><i class="fa-brands fa-github"></i> Code</a></li>
                    </ul>
                </div> */}
                 
               
            </div>

            </div>
        </section>
        </>
    );
}